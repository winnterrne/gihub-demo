package BaiTapTrenLop;

import java.util.Scanner;

public class Baitap1d {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int count = 0;
        while(x > 0) {
            count++;
            x /= 10;
        }
        System.out.println(count);
    }
}